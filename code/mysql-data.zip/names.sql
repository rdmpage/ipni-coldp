-- MySQL dump 10.13  Distrib 5.7.18, for macos10.12 (x86_64)
--
-- Host: localhost    Database: ipni
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `names`
--

DROP TABLE IF EXISTS `names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `names` (
  `Id` varchar(16) NOT NULL DEFAULT '',
  `Version` varchar(16) DEFAULT NULL,
  `cluster_id` varchar(16) DEFAULT NULL,
  `Family` varchar(255) DEFAULT NULL,
  `Infra_family` varchar(255) DEFAULT NULL,
  `Hybrid_genus` enum('Y','N') DEFAULT NULL,
  `Genus` varchar(255) DEFAULT NULL,
  `Infra_genus` varchar(255) DEFAULT NULL,
  `Hybrid` enum('Y','N') DEFAULT NULL,
  `Species` varchar(255) DEFAULT NULL,
  `Infra_species` varchar(255) DEFAULT NULL,
  `Rank` varchar(32) DEFAULT NULL,
  `Authors` varchar(255) DEFAULT NULL,
  `Basionym_author` varchar(255) DEFAULT NULL,
  `Publishing_author` varchar(255) DEFAULT NULL,
  `Full_name_without_family_and_authors` varchar(255) DEFAULT NULL,
  `Publication` varchar(255) DEFAULT NULL,
  `Collation` varchar(255) DEFAULT NULL,
  `Publication_year_full` varchar(32) DEFAULT NULL,
  `Name_status` varchar(32) DEFAULT NULL,
  `Remarks` varchar(255) DEFAULT NULL,
  `Basionym` varchar(255) DEFAULT NULL,
  `Replaced_synonym` varchar(255) DEFAULT NULL,
  `Nomenclatural_synonym` varchar(255) DEFAULT NULL,
  `Distribution` varchar(255) DEFAULT NULL,
  `Citation_type` varchar(255) DEFAULT NULL,
  `issn` char(9) DEFAULT NULL,
  `microreference` varchar(255) DEFAULT NULL,
  `selector` varchar(255) DEFAULT NULL,
  `doi` varchar(255) DEFAULT NULL,
  `pmid` int(11) DEFAULT NULL,
  `biostor` int(11) DEFAULT NULL,
  `jstor` int(11) DEFAULT NULL,
  `bhl` int(11) DEFAULT NULL,
  `bhl_score` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `pdf` text,
  `cinii` varchar(16) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `isbn` char(13) DEFAULT NULL,
  `oclc` int(11) DEFAULT NULL,
  `updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Basionym_Id` varchar(16) DEFAULT NULL,
  `sici` varchar(255) DEFAULT NULL,
  `doi_agency` varchar(32) DEFAULT NULL,
  `wikidata` varchar(32) DEFAULT NULL,
  `wikidata_taxon` varchar(32) DEFAULT NULL,
  `wikidata_done` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Version` (`Version`),
  KEY `Family` (`Family`),
  KEY `Infra_family` (`Infra_family`),
  KEY `Hybrid_genus` (`Hybrid_genus`),
  KEY `Genus` (`Genus`),
  KEY `Infra_genus` (`Infra_genus`),
  KEY `Hybrid` (`Hybrid`),
  KEY `Species` (`Species`),
  KEY `Infra_species` (`Infra_species`),
  KEY `Rank` (`Rank`),
  KEY `Authors` (`Authors`),
  KEY `Full_name_without_family_and_authors` (`Full_name_without_family_and_authors`),
  KEY `Publication` (`Publication`),
  KEY `Collation` (`Collation`),
  KEY `Publication_year_full` (`Publication_year_full`),
  KEY `Citation_type` (`Citation_type`),
  KEY `issn` (`issn`),
  KEY `doi` (`doi`),
  KEY `Remarks` (`Remarks`),
  KEY `biostor` (`biostor`),
  KEY `Basionym` (`Basionym`),
  KEY `Publishing_author` (`Publishing_author`),
  KEY `url` (`url`),
  KEY `bhl` (`bhl`),
  KEY `handle` (`handle`),
  KEY `Basionym_Id` (`Basionym_Id`),
  KEY `pdf` (`pdf`(255)),
  KEY `doi_agency` (`doi_agency`),
  KEY `cluster_id` (`cluster_id`),
  KEY `oclc` (`oclc`),
  KEY `selector` (`selector`),
  KEY `wikidata` (`wikidata`),
  KEY `jstor` (`jstor`),
  KEY `cinii` (`cinii`),
  KEY `wikidata_taxon` (`wikidata_taxon`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-25 13:50:35
